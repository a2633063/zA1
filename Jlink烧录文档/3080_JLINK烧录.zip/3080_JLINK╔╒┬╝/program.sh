#!/bin/sh

echo Downloading firmware ...
./openocd/osx/openocd_mico -f openocd/scripts/interface/jlink_swd.cfg -f openocd/scripts/target/MX1290/MX1290.cfg -f sflash_write.tcl -c "sflash_write_file firmware/boot.bin 1 0x0 MK3080B 0" -c "sflash_write_file firmware/ota.bin 2 0x0 MK3080B 0" -c "sflash_write_file firmware/ate.bin 3 0x0 MK3080B 0" -c shutdown > log.txt 2>&1
echo Done!