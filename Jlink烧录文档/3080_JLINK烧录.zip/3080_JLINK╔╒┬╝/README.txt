1. 把 xxx@moc.all.bin 复制到 firmware 内，并重命名为 all.bin。
2. 执行 split.bat，将 all.bin 分割为 boot.bin ota.bin 和 ate.bin。
3. 连接 J-Link 到模块上，执行 program.bat，开始烧写，等待烧写完毕。

注意：对于一个新的 all.bin，步骤 2 只需执行一次即可。