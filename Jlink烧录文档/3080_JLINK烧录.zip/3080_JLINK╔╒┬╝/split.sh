#!/bin/sh

dd bs=1 count=72k if=firmware/all.bin of=firmware/boot.bin
dd bs=1 count=724k skip=76k if=firmware/all.bin of=firmware/ota.bin
dd bs=1 count=256k skip=832k if=firmware/all.bin of=firmware/ate.bin